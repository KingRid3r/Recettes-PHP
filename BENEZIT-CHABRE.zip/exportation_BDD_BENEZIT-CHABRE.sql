-- phpMyAdmin SQL Dump
-- version 4.0.10.6
-- http://www.phpmyadmin.net
--
-- Host: mysql-luca-benezit.alwaysdata.net
-- Generation Time: Jan 08, 2018 at 04:50 AM
-- Server version: 10.1.23-MariaDB
-- PHP Version: 5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `luca-benezit_mvc`
--

-- --------------------------------------------------------

--
-- Table structure for table `T_FAVORIS_FAV`
--

CREATE TABLE IF NOT EXISTS `T_FAVORIS_FAV` (
  `FAV_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `FAV_TITRE` varchar(255) NOT NULL,
  `FAV_LIEN` varchar(255) NOT NULL,
  `FAV_DESCRIPTION` longtext NOT NULL,
  PRIMARY KEY (`FAV_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
--
-- Database: `luca-benezit_projet`
--

-- --------------------------------------------------------

--
-- Table structure for table `TJ_CAT_RCT`
--

CREATE TABLE IF NOT EXISTS `TJ_CAT_RCT` (
  `CAT_ID` bigint(20) unsigned NOT NULL,
  `RCT_ID` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`CAT_ID`,`RCT_ID`),
  KEY `CAT_ID` (`CAT_ID`),
  KEY `RCT_ID` (`RCT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `TJ_CAT_RCT`
--

INSERT INTO `TJ_CAT_RCT` (`CAT_ID`, `RCT_ID`) VALUES
(1, 3),
(1, 5),
(2, 2),
(2, 4),
(2, 6),
(3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `TJ_IGD_RCT_UNI`
--

CREATE TABLE IF NOT EXISTS `TJ_IGD_RCT_UNI` (
  `RCT_ID` bigint(20) unsigned NOT NULL,
  `IGD_LABEL` varchar(255) NOT NULL,
  `UNI_LABEL` varchar(30) NOT NULL,
  `IGD_RCT_UNI_QUANTITE` int(11) NOT NULL,
  PRIMARY KEY (`RCT_ID`,`IGD_LABEL`,`UNI_LABEL`),
  KEY `C_FK_IGD_IGD_RCT_UNI` (`IGD_LABEL`),
  KEY `C_FK_UNI_IGD_RCT_UNI` (`UNI_LABEL`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `T_CATEGORIE_CAT`
--

CREATE TABLE IF NOT EXISTS `T_CATEGORIE_CAT` (
  `CAT_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `CAT_LABEL` varchar(255) NOT NULL,
  `CAT_DESCRIPTION` mediumtext NOT NULL,
  `CAT_ILLUSTRATION` varchar(80) NOT NULL,
  PRIMARY KEY (`CAT_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `T_CATEGORIE_CAT`
--

INSERT INTO `T_CATEGORIE_CAT` (`CAT_ID`, `CAT_LABEL`, `CAT_DESCRIPTION`, `CAT_ILLUSTRATION`) VALUES
(1, 'Entrée', 'Ce qu''il y a au debut du repas', 'entree.jpg'),
(2, 'Plat', 'Ce qu''on mange au milieu', 'plat.jpg'),
(3, 'Dessert', 'Ce qu''on mange a la fin', 'dessert.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `T_COMMENTAIRE_COM`
--

CREATE TABLE IF NOT EXISTS `T_COMMENTAIRE_COM` (
  `COM_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `COM_TEXTE` mediumtext NOT NULL,
  `COM_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UTI_ID` bigint(20) unsigned DEFAULT NULL,
  `RCT_ID` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`COM_ID`),
  KEY `RCT_ID` (`RCT_ID`),
  KEY `UTI_ID` (`UTI_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `T_COMMENTAIRE_COM`
--

INSERT INTO `T_COMMENTAIRE_COM` (`COM_ID`, `COM_TEXTE`, `COM_DATE`, `UTI_ID`, `RCT_ID`) VALUES
(1, 'test', '2018-01-08 02:49:35', 4, 3),
(2, 'test2', '2018-01-08 03:18:25', 1, 3),
(3, 'test2', '2018-01-08 03:18:31', 1, 3),
(4, 'dd', '2018-01-08 03:24:21', 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `T_INGREDIENT_IGD`
--

CREATE TABLE IF NOT EXISTS `T_INGREDIENT_IGD` (
  `IGD_LABEL` varchar(255) NOT NULL,
  `IGD_DESCRIPTION` mediumtext NOT NULL,
  `IGD_ILLUSTRATION` varchar(80) DEFAULT NULL,
  `IGD_VALIDE` tinyint(1) NOT NULL DEFAULT '0',
  `UTI_ID` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`IGD_LABEL`),
  KEY `IGD_LABEL` (`IGD_LABEL`),
  KEY `C_FK_UTI_IGD` (`UTI_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `T_RECETTE_RCT`
--

CREATE TABLE IF NOT EXISTS `T_RECETTE_RCT` (
  `RCT_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `RCT_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `RCT_TITRE` varchar(80) NOT NULL,
  `RCT_DESCRIPTION` longtext NOT NULL,
  `RCT_TEMPS_PREPARATION` time NOT NULL,
  `RCT_TEMPS_CUISSON` time DEFAULT '00:00:00',
  `RCT_TEMPS_REPOS` time DEFAULT '00:00:00',
  `RCT_DIFFICULTE` enum('facile','moyen','difficile') NOT NULL DEFAULT 'facile',
  `RCT_COUT` enum('faible','moyen','eleve') NOT NULL DEFAULT 'faible',
  `RCT_STATUT` enum('brouillon','soumise','finale') NOT NULL DEFAULT 'brouillon',
  `RCT_ILLUSTRATION` varchar(80) NOT NULL,
  `UTI_ID` bigint(20) unsigned NOT NULL,
  `RCT_NBPERSONNE` int(11) NOT NULL,
  `RCT_RECETTE` text NOT NULL,
  `RCT_NOTE` int(5) NOT NULL,
  PRIMARY KEY (`RCT_ID`),
  KEY `UTI_ID` (`UTI_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `T_RECETTE_RCT`
--

INSERT INTO `T_RECETTE_RCT` (`RCT_ID`, `RCT_DATE`, `RCT_TITRE`, `RCT_DESCRIPTION`, `RCT_TEMPS_PREPARATION`, `RCT_TEMPS_CUISSON`, `RCT_TEMPS_REPOS`, `RCT_DIFFICULTE`, `RCT_COUT`, `RCT_STATUT`, `RCT_ILLUSTRATION`, `UTI_ID`, `RCT_NBPERSONNE`, `RCT_RECETTE`, `RCT_NOTE`) VALUES
(1, '2017-12-06 10:11:33', 'PanCakes', 'C''est très bon wallah !', '00:30:00', '00:01:00', '00:00:00', 'facile', 'faible', 'finale', 'pancakes.jpg', 1, 999, 'gthtfjfgjgfhder', 0),
(2, '2017-12-06 10:11:33', 'Saumon', 'C''est très bon le saumon ', '01:00:00', '00:30:00', '00:00:00', 'moyen', 'moyen', 'finale', 'saumon.jpg', 1, 2, 'gsdgdsgdsg', 0),
(3, '2017-12-06 10:18:26', 'Aspèrge', 'La maman de Antho en rafolle', '00:30:00', '00:00:00', '00:00:00', 'moyen', 'faible', 'soumise', 'asperge.jpg', 2, 5, 'sgrrdgrdsg', 3),
(4, '2017-12-06 10:18:26', 'Boblechef', 'ça perche de ouf', '01:00:00', '00:30:00', '00:00:00', 'moyen', 'eleve', 'finale', 'boblechef.jpg', 2, 999, 'gsegdsgsfg', 0),
(5, '2017-12-06 10:24:10', 'Poisson mozza', 'Remi en raffole', '00:30:00', '00:15:00', '00:00:00', 'moyen', 'faible', 'soumise', 'mozza.jpg', 3, 10, 'gsdfgrsgfs', 0),
(6, '2017-12-06 10:24:10', 'Taggliatelles', 'C''est degeux mais pas cher', '00:30:00', '00:10:00', '00:00:00', 'facile', 'faible', 'finale', 'Tagliatelles.jpg', 3, 3, 'gdsfgsg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `T_UNITE_UNI`
--

CREATE TABLE IF NOT EXISTS `T_UNITE_UNI` (
  `UNI_LABEL` varchar(30) NOT NULL,
  `UNI_SHORT_LABEL` varchar(15) NOT NULL,
  `UNI_DESCRIPTION` mediumtext NOT NULL,
  `UNI_VALIDE` tinyint(1) NOT NULL DEFAULT '0',
  `UTI_ID` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`UNI_LABEL`),
  KEY `UTI_ID` (`UTI_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `T_UTILISATEUR_UTI`
--

CREATE TABLE IF NOT EXISTS `T_UTILISATEUR_UTI` (
  `UTI_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `UTI_LOGIN` varchar(255) NOT NULL,
  `UTI_MAIL` varchar(255) NOT NULL,
  `UTI_NOM` varchar(255) NOT NULL,
  `UTI_PRENOM` varchar(255) NOT NULL,
  `UTI_PASS` varchar(40) NOT NULL,
  `UTI_ADMIN` tinyint(1) NOT NULL DEFAULT '0',
  `UTI_AVATAR` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`UTI_ID`),
  UNIQUE KEY `UTI_LOGIN` (`UTI_LOGIN`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `T_UTILISATEUR_UTI`
--

INSERT INTO `T_UTILISATEUR_UTI` (`UTI_ID`, `UTI_LOGIN`, `UTI_MAIL`, `UTI_NOM`, `UTI_PRENOM`, `UTI_PASS`, `UTI_ADMIN`, `UTI_AVATAR`) VALUES
(1, 'KingRid3r', '', '', '', 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3', 0, 'KingRid3r.png'),
(2, 'Rockend', '', '', '', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', 0, 'Rockend.png'),
(3, 'ADMIN', '', '', '', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', 1, 'ADMIN.png'),
(4, 'postgres', 'test@test.frfff', 'test', 'tester', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', 1, 'ava.png'),
(5, 'mathieu221098', '', '', '', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', 0, 'ava.png');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `TJ_CAT_RCT`
--
ALTER TABLE `TJ_CAT_RCT`
  ADD CONSTRAINT `C_FK_CAT_CAT_RCT` FOREIGN KEY (`CAT_ID`) REFERENCES `T_CATEGORIE_CAT` (`CAT_ID`),
  ADD CONSTRAINT `C_FK_RCT_CAT_RCT` FOREIGN KEY (`RCT_ID`) REFERENCES `T_RECETTE_RCT` (`RCT_ID`);

--
-- Constraints for table `TJ_IGD_RCT_UNI`
--
ALTER TABLE `TJ_IGD_RCT_UNI`
  ADD CONSTRAINT `C_FK_IGD_IGD_RCT_UNI` FOREIGN KEY (`IGD_LABEL`) REFERENCES `T_INGREDIENT_IGD` (`IGD_LABEL`),
  ADD CONSTRAINT `C_FK_RCT_IGD_RCT_UNI` FOREIGN KEY (`RCT_ID`) REFERENCES `T_RECETTE_RCT` (`RCT_ID`),
  ADD CONSTRAINT `C_FK_UNI_IGD_RCT_UNI` FOREIGN KEY (`UNI_LABEL`) REFERENCES `T_UNITE_UNI` (`UNI_LABEL`);

--
-- Constraints for table `T_COMMENTAIRE_COM`
--
ALTER TABLE `T_COMMENTAIRE_COM`
  ADD CONSTRAINT `C_FK_RCT_COM` FOREIGN KEY (`RCT_ID`) REFERENCES `T_RECETTE_RCT` (`RCT_ID`),
  ADD CONSTRAINT `C_FK_UTI_COM` FOREIGN KEY (`UTI_ID`) REFERENCES `T_UTILISATEUR_UTI` (`UTI_ID`);

--
-- Constraints for table `T_INGREDIENT_IGD`
--
ALTER TABLE `T_INGREDIENT_IGD`
  ADD CONSTRAINT `C_FK_UTI_IGD` FOREIGN KEY (`UTI_ID`) REFERENCES `T_UTILISATEUR_UTI` (`UTI_ID`);

--
-- Constraints for table `T_RECETTE_RCT`
--
ALTER TABLE `T_RECETTE_RCT`
  ADD CONSTRAINT `C_FK_UTI_RCT` FOREIGN KEY (`UTI_ID`) REFERENCES `T_UTILISATEUR_UTI` (`UTI_ID`);

--
-- Constraints for table `T_UNITE_UNI`
--
ALTER TABLE `T_UNITE_UNI`
  ADD CONSTRAINT `C_FK_UNI_UTI` FOREIGN KEY (`UTI_ID`) REFERENCES `T_UTILISATEUR_UTI` (`UTI_ID`);
--
-- Database: `luca-benezit_tp2`
--

-- --------------------------------------------------------

--
-- Table structure for table `T_UTILISATEUR_UTI`
--

CREATE TABLE IF NOT EXISTS `T_UTILISATEUR_UTI` (
  `UTI_LOGIN` varchar(255) NOT NULL,
  `UTI_PWD` varchar(255) NOT NULL,
  `UTI_MAIL` varchar(255) NOT NULL,
  `UTI_TEL` varchar(20) DEFAULT NULL,
  `UTI_NOM` varchar(255) NOT NULL,
  `UTI_PRENOM` varchar(255) NOT NULL,
  `UTI_ADMIN` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`UTI_LOGIN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `T_UTILISATEUR_UTI`
--

INSERT INTO `T_UTILISATEUR_UTI` (`UTI_LOGIN`, `UTI_PWD`, `UTI_MAIL`, `UTI_TEL`, `UTI_NOM`, `UTI_PRENOM`, `UTI_ADMIN`) VALUES
('KingRid3r', '9cf95dacd226dcf43da376cdb6cbba7035218921', 'luca.benezit@icloud.com', '+33685955153', 'bene', 'bene', 0),
('luca13', 'a05bd890c4868ea1807f8564055d1fba77c6ba81', 'luca.benezit@icloud.com', '0685955153', 'Benezit', 'Luca', 0),
('rey-lucario', '403926033d001b5279df37cbbe5287b7c7c267fa', 'luca.benezit@icloud.com', '0685955153', 'Benezit', 'Luca', 0),
('test_user', 'cbe0021925fbe6cfd91f2f6b280b053ebadc569f', 'test_user@gmail.fr', NULL, 'Carmi', 'Laurent', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
