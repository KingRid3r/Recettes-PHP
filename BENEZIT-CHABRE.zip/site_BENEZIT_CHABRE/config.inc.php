<?php
	$_PAGE = array('acc' => 'acceuil', 'recettes' => 'recette_liste', 'contacts' => 'contacts', 'detail' => 'recette_detail', '404' => 'erreur404', 'connection' => 'connection', 'inscription' => 'inscription', 'deconnection' => 'deconnection', 'moncompte' => 'profil', 'ajout' => 'ajout_recette');
?>
