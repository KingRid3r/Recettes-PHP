<?php
/* Smarty version 3.1.30, created on 2017-12-27 15:35:36
  from "C:\xampp\htdocs\Recettes-PHP\site\application\views\layout\layout_entete.inc.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a43afb8399159_92992852',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '35814f6b3b04e64cce4c793149c9524c11441346' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Recettes-PHP\\site\\application\\views\\layout\\layout_entete.inc.tpl',
      1 => 1514385217,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a43afb8399159_92992852 (Smarty_Internal_Template $_smarty_tpl) {
?>
<img id="top" class="center-block img-responsive" style="width:80%" src="asset/images/logo_site.png" alt="logo site" />
<?php }
}
