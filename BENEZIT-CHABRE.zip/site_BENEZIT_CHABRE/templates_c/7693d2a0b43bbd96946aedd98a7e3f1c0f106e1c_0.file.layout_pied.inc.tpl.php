<?php
/* Smarty version 3.1.30, created on 2017-12-27 15:35:36
  from "C:\xampp\htdocs\Recettes-PHP\site\application\views\layout\layout_pied.inc.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a43afb8412ae0_40488602',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7693d2a0b43bbd96946aedd98a7e3f1c0f106e1c' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Recettes-PHP\\site\\application\\views\\layout\\layout_pied.inc.tpl',
      1 => 1514385217,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a43afb8412ae0_40488602 (Smarty_Internal_Template $_smarty_tpl) {
?>
		<a href="#top" class="bouton btn btn-primary" role="button"><span class="glyphicon glyphicon-arrow-up"></span></a>
		<footer class="row">
 			<p class="text-center">&copy; Copyright 2017 Luca BENEZIT, Mathieu CHABRE - Tous droits réservés</p>
 		</footer>
<?php }
}
