<?php
/* Smarty version 3.1.30, created on 2018-01-08 00:12:55
  from "C:\xampp\htdocs\Recettes-PHP\site\application\views\nav\nav_admin.inc.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a52a977408915_07065488',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8ad9ace671586f9836a6128701a79d2515251de6' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Recettes-PHP\\site\\application\\views\\nav\\nav_admin.inc.tpl',
      1 => 1515366446,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a52a977408915_07065488 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="col-sm-2" id="mySidebar">
  <div class="row">
    <nav class="nav-sidebar sidebar">
      <ul class="nav">
        <li class="active"><a href="compte.php">Informations personnelles</a></li>
        <li><a href="gerer_recettes.php">Gerer les recettes</a></li>
        <li><a href="suppression.php">Supprimer le compte</a></li>
      </ul>
    </nav>
  </div>
</div>
<?php }
}
